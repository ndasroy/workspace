package org.testng.internal.annotations;

public class AfterSuiteAnnotation extends BaseBeforeAfter {

}

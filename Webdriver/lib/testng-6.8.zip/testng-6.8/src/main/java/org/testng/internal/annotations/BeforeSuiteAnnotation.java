package org.testng.internal.annotations;

public class BeforeSuiteAnnotation extends BaseBeforeAfter {

}
